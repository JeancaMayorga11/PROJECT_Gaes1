package com.asago3.asago3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Asago3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
